# openQCMdataprep
Jupyter notebook for data processing from openQCM
